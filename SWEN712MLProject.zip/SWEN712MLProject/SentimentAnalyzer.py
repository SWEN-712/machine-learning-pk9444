'''
SWEN 712 - Engineering Accessibility Software
Project 2 - ML
@developed by: Pratyush Karna, MS Software Engineering
SentimentAnalyzer.py
Python 3.8.2

This project retrieves tweets from the twitter of NV Access, which has developed NVDA, a free Open source
software for the blind or for those with visual impairments and make the features more accessible to them.
We first retrieve the first 1000 tweets using the tweepy library from NV Access' official Twitter handle.
Then using sentiment analysis library textblob, we define the sentiment polarity and classify the tweets based
on positive, negative and the remaining neutral. We also, retrieve the top 10 positive and negative tweets out of
the total 1000 tweets. Lastly, we use matplotlib to visualize our results for better understanding.

'''
# -*- coding: utf-8 -*-
# import all the required libraries
import re
import tweepy
from tweepy import OAuthHandler
from textblob import TextBlob
import matplotlib.pyplot as plt


class TwitterSentimentAnalyzer(object):
    '''
    Defining the class name which is the blueprint of the program - It is perform sentiment analysis on tweets for NVAccess
    '''

    def __init__(self):
        '''
        Initializing the Class Constructor
        '''
        # we retrieve the public and secret keys and token from Twitter Dev resources
        consumer_key = '20SykH0Aizk1ZYSHdsUoPA6D5'
        consumer_secret = 'WcbAnkKPzraaxFUXngnld8JEGPj5Hkzr7qnjawwxhlpC6n0DXR'
        access_token = '1227789853720444928-HUm6NAXAztfTaLqG7ORdnZCZmxErBf'
        access_token_secret = '9ZA1CP1EYGQ63Aj209Jli2mrckTZgXQdGvzICyMuUasao'

        # Handle Exceptions - Failed Authentication
        try:
            # create OAuthHandler object
            self.auth = OAuthHandler(consumer_key, consumer_secret)
            # set access token and secret
            self.auth.set_access_token(access_token, access_token_secret)
            # create tweepy API object to fetch tweets
            self.api = tweepy.API(self.auth)
        except:
            print("Error: Authentication Failed")

    def clean_tweets(self, tweets):
        '''
        Function to clean the tweets text by eliminating links, special characters
        by using regular expression.
        '''
        return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t]) |(\w+:\/\/\S+)", " ",
                               tweets).split())  # split them along the eliminated tokens

    def get_sentiment(self, tweet):
        '''
        Function to classify the sentiment of a tweet passed as the argument
        by computing its polarity and classifying as per the computed score
        '''
        # Instantiate Textblob - and pass the return value from clean_tweets() method in the object declaration
        analyzer = TextBlob(self.clean_tweets(tweet))
        # set sentiment labels as per the polarity score
        if analyzer.sentiment.polarity > 0:
            return 'positive'
        elif analyzer.sentiment.polarity == 0:
            return 'neutral'
        else:
            return 'negative'

    def get_tweets(self, query, count=10):
        '''
        Funtion to fecth the tweets and parse them in a list
        '''
        # empty list to store parsed tweets
        tweets_array = []

        # Handle Exception - This control flow handles tweepy related exception
        try:  # Normal Flow
            # call twitter api to fetch tweets and store it
            fetched_tweets = self.api.search(q=query, count=count)

            # parse the tweets one at a time
            for given_tweet in fetched_tweets:
                # store them in the dictionary
                parsed_tweet = {}

                # storing text of the tweet in the dictionary
                parsed_tweet['text'] = given_tweet.text
                # storing sentiment of the tweet in the dictionary
                parsed_tweet['sentiment'] = self.get_sentiment(given_tweet.text)

                # appending parsed tweet to tweets array
                if given_tweet.retweet_count > 0:
                    # if tweet has retweets, ensure that it is appended only once
                    if parsed_tweet not in tweets_array:
                        tweets_array.append(parsed_tweet)
                else:
                    tweets_array.append(parsed_tweet)

                    # return parsed tweets
            return tweets_array


        except tweepy.TweepError as e:  # Exception Flow
            # print error (if any)
            print("Error : " + str(e))


def main():
    '''
    driver function of the Class
    '''
    # creating object of TwitterClient Class
    api = TwitterSentimentAnalyzer()
    # calling function to get all the tweets

    total_tweets = api.get_tweets(query='NVAccess', count=100)

    # retrieving the positive tweets from the total tweets
    positive_tweets = [tweet for tweet in total_tweets if tweet['sentiment'] == 'positive']

    # Computing the percentage of the positive tweets and printing it
    positive_percentage = (len(positive_tweets) / len(total_tweets)) * 100
    print("Positive Tweets Percentage: " + str(positive_percentage))

    # similarly retrieving the negatice from the total tweets
    negative_tweets = [tweet for tweet in total_tweets if tweet['sentiment'] == 'negative']

    # now computing the percentage of negative tweeta and printing it
    negative_percentage = (len(negative_tweets) / len(total_tweets)) * 100
    print("Negative Tweets Percentage: " + str(negative_percentage))
    # print("Negative tweets percentage: {} %".format(100*len(ntweets)/len(tweets)))

    # percentage of neutral tweets

    # print("Neutral tweets percentage: {} % \ ".format(100-ptweets-ntweets))
    neutral_percentage = 100 - (positive_percentage + negative_percentage)

    # retrieving the top 5 positive tweets about NVAccess
    print("\n\n Top 10 Positive tweets about @NVAccess:")
    for tweet in positive_tweets[:20]:
        print(tweet['text'])

        # retrieving the top 5 negative tweets about NVAccess
    print("\n\n Top 10 Negative tweets about @NVAccess:")
    for tweet in negative_tweets[:20]:
        print(tweet['text'])

    # Creating a pie chart for visualizing the percentage composition over the first 100 tweets
    labels = ['Positive Tweets', 'Negative Tweets', 'Neutral Tweets']
    sizes = [positive_percentage, negative_percentage, neutral_percentage]
    colors = ['#23C8D1', 'red', '#D1D123']
    explode = (0, 0, 0)
    plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%', shadow=False, startangle=90)
    plt.axis('equal')
    plt.title('Sentiment Percentage Composition - @NVAccess')
    plt.show()


if __name__ == "__main__":
    # Lastly, calling main function
    main()

# end